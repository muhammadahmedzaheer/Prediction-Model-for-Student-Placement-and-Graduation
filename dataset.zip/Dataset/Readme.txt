Problem Statement 1: Prediction of Placement status data
There is 2 files- 1 is '01 Train Data' & 2 is '02 Test Data'.

Problem Statement 2: Calculation for Year of graduation data
There is only 1 file 'Final Lead Data'